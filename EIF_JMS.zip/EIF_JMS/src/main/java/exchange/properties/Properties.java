package exchange.properties;

public class Properties
{
    public static String jmsurl        = "ssl://stg001eu1-msgbus-1.3dexperience.3ds.com:61617";
    public static String tenantid      = "OI000399516";
    public static String agent_id      = "d4f1ae32-61c0-487f-8743-8da23c3eea1f";
    public static String agent_credentials = "{tOu;uS280}7r,HF8,Zh/k*=";

    public static String sec_context   = "VPLMProjectLeader.Company Name.ELGI";
    public static String sec_context_common = "VPLMProjectLeader.Company Name.Common Space";

    public static String space3ds_url_str = "https://oi000399516-eu1-space.3dexperience.3ds.com/enovia";

    // LN endpoint — plain POST, no auth required
    public static String ln_url = "https://edex.elgi.com:8443/c4ws/services/PLMAttribute/ElgiNewTest?wsdl";
}