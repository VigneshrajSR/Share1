package exchange.util;

import java.io.UnsupportedEncodingException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import exchange.properties.Properties;

/**
 * EID_service — single point for ALL outbound REST/SOAP calls used by
 * the consolidated event listener (Drawing Title Update + Spec-Sheet LN Sync).
 */
public class EID_service
{
    public static String agent_id = Properties.agent_id;
    public static String agent_credentials = Properties.agent_credentials;
    public static String _tenant = Properties.tenantid;
    public static String _space3ds_url_str = Properties.space3ds_url_str;

    public static String _csrf_token_url =
            _space3ds_url_str + "/resources/v1/application/CSRF" + "?tenant=" + _tenant;

    public static String _csrf_token = "";
    public static String _basicauthentication = "";

    public String contextId = null;
    public static HttpClient httpClient = null;

    public EID_service(String id)
    {
        contextId = id;
        httpClient = HttpClient.newBuilder()
                .cookieHandler(new CookieManager(null, CookiePolicy.ACCEPT_ALL))
                .followRedirects(HttpClient.Redirect.ALWAYS)
                .build();
    }

    // ================================================================
    // AUTH
    // ================================================================
    public String prepareAuthorizationHeaderValue() throws UnsupportedEncodingException
    {
        String loginandpassword = agent_id + ":" + agent_credentials;
        String base64 = Base64.getEncoder().encodeToString(loginandpassword.getBytes("utf-8"));
        _basicauthentication = "Basic " + base64;
        System.out.println("[EID_service] Authorization header prepared for agent: " + agent_id);
        System.out.println("_basicauthentication"+_basicauthentication);
        return _basicauthentication;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static String get_csrf_token() throws Exception
    {
        HashMap headers = new HashMap();
        HttpResponse response = load_url(httpClient, "GET", "", "", _csrf_token_url, headers);

        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(response.body().toString());

        if (json.get("success") != null && json.get("success").toString().equalsIgnoreCase("true"))
        {
            JSONObject csrf = (JSONObject) json.get("csrf");
            _csrf_token = csrf.get("value").toString();
            System.out.println("[EID_service] CSRF token fetched successfully.");
        }
        else
        {
            System.err.println("[EID_service] CSRF token fetch FAILED. Response: " + response.body());
        }
        return _csrf_token;
    }

    // ================================================================
    // DRAWING TITLE UPDATE — FLOW APIs
    // ================================================================
    @SuppressWarnings({ "serial", "unchecked", "rawtypes" })
    public String get_drawing_with_parent(String drawingId, String secContext) throws Exception
    {
        String targetURL = _space3ds_url_str
                + "/resources/v1/modeler/dsdrw/dsdrw:Drawing/" + drawingId
                + "?$mask=dsmvdrw:DrawingMask.ParentEngItems"
                + "&tenant=" + _tenant;

        HashMap headers = new HashMap()
        {{
            put("Authorization", _basicauthentication);
            put("SecurityContext", secContext);
        }};

        System.out.println("[EID_service] Calling GET Drawing+Parent -> " + targetURL);
        HttpResponse response = load_url(httpClient, "GET", "application/json", "", targetURL, headers);
        System.out.println("[EID_service] GET Drawing+Parent status: " + response.statusCode());
        return response.body().toString();
    }

    @SuppressWarnings({ "serial", "unchecked", "rawtypes" })
    public String get_vpm_details(String vpmId, String secContext) throws Exception
    {
        String targetURL = _space3ds_url_str
                + "/resources/v1/modeler/dseng/dseng:EngItem/" + vpmId
                + "?$mask=dsmveng:EngItemMask.Details"
                + "&tenant=" + _tenant;

        HashMap headers = new HashMap()
        {{
            put("Authorization", _basicauthentication);
            put("SecurityContext", secContext);
        }};

        System.out.println("[EID_service] Calling GET VPMReference -> " + targetURL);
        HttpResponse response = load_url(httpClient, "GET", "application/json", "", targetURL, headers);
        System.out.println("[EID_service] GET VPMReference status: " + response.statusCode());
        return response.body().toString();
    }

    @SuppressWarnings({ "serial", "unchecked", "rawtypes" })
    public void patch_drawing_title(String drawingId, String drawingCestamp, String newTitle, String secContext) throws Exception
    {
        String targetURL = _space3ds_url_str
                + "/resources/v1/modeler/dsdrw/dsdrw:Drawing/" + drawingId
                + "?tenant=" + _tenant;

        _csrf_token = get_csrf_token();

        JSONObject requestBodyJson = new JSONObject();
        requestBodyJson.put("cestamp", drawingCestamp);
        requestBodyJson.put("title", newTitle);
        String requestBody = requestBodyJson.toJSONString();

        HashMap headers = new HashMap()
        {{
            put("Authorization", _basicauthentication);
            put("SecurityContext", secContext);
            put("ENO_CSRF_TOKEN", _csrf_token);
        }};

        System.out.println("[EID_service] PATCH Drawing title -> " + targetURL);
        System.out.println("[EID_service] PATCH body: " + requestBody);
        HttpResponse response = load_url(httpClient, "PATCH", "application/json", requestBody, targetURL, headers);
        System.out.println("[EID_service] PATCH Drawing title status: " + response.statusCode());
        System.out.println("[EID_service] PATCH Drawing title response: " + response.body());
    }

    // ================================================================
    // SPEC-SHEET LN SYNC — FLOW APIs
    // ================================================================
    @SuppressWarnings({ "serial", "unchecked", "rawtypes" })
    public String get_document_details(String docId, String secContext) throws Exception
    {
        String targetURL = _space3ds_url_str
                + "/resources/v1/modeler/documents/" + docId
                + "?tenant=" + _tenant;

        HashMap headers = new HashMap()
        {{
            put("Authorization", _basicauthentication);
            put("SecurityContext", secContext);
        }};

        System.out.println("[EID_service] Calling GET Document Details -> " + targetURL);
        HttpResponse response = load_url(httpClient, "GET", "application/json", "", targetURL, headers);
        System.out.println("[EID_service] GET Document Details status: " + response.statusCode());
        return response.body().toString();
    }

    @SuppressWarnings({ "serial", "unchecked", "rawtypes" })
    public String get_child_documents(String parentDocId, String secContext) throws Exception
    {
        String targetURL = _space3ds_url_str
                + "/resources/v1/modeler/documents/parentId/" + parentDocId
                + "?parentRelName=" + java.net.URLEncoder.encode("Reference Document", java.nio.charset.StandardCharsets.UTF_8)
                + "&tenant=" + _tenant;

        HashMap headers = new HashMap()
        {{
            put("Authorization", _basicauthentication);
            put("SecurityContext", secContext);
        }};

        System.out.println("[EID_service] Calling GET Child Documents -> " + targetURL);
        HttpResponse response = load_url(httpClient, "GET", "application/json", "", targetURL, headers);
        System.out.println("[EID_service] GET Child Documents status: " + response.statusCode());
        return response.body().toString();
    }

    @SuppressWarnings({ "serial", "unchecked", "rawtypes" })
    public String get_classification_attributes(String docId, String secContext) throws Exception
    {
        String targetURL = _space3ds_url_str
                + "/resources/v1/modeler/dslib/dslib:ClassifiedItem/" + docId
                + "?$mask=dslib:ClassificationAttributesMask"
                + "&tenant=" + _tenant;

        HashMap headers = new HashMap()
        {{
            put("Authorization", _basicauthentication);
            put("SecurityContext", secContext);
        }};

        System.out.println("[EID_service] Calling GET Classification Attributes -> " + targetURL);
        HttpResponse response = load_url(httpClient, "GET", "application/json", "", targetURL, headers);
        System.out.println("[EID_service] GET Classification Attributes status: " + response.statusCode());
        return response.body().toString();
    }

    /**
     * Builds the SOAP XML body exactly matching the ELGI LN Postman collection format.
     */
    public String build_ln_soap_payload(String item, String revision, JSONArray attributes,
                                        String specRefNo, String specRevision)
    {
        StringBuilder attrXml = new StringBuilder();
        for (Object attrObj : attributes)
        {
            JSONObject attr = (JSONObject) attrObj;
            String name = attr.get("name") != null ? attr.get("name").toString() : "";
            String value = attr.get("value") != null ? attr.get("value").toString() : "";
            attrXml.append("<Attributes>")
                    .append("<AttributeName>").append(escapeXml(name)).append("</AttributeName>")
                    .append("<AttributeValue>").append(escapeXml(value)).append("</AttributeValue>")
                    .append("</Attributes>");
        }

        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "xmlns:plm=\"http://www.infor.com/businessinterface/PLMAttribute\">"
                + "<soapenv:Header><plm:Activation><company>400</company></plm:Activation></soapenv:Header>"
                + "<soapenv:Body><plm:InsertData><InsertDataRequest><DataArea>"
                + "<PLMAttribute>"
                + "<Item>" + escapeXml(item) + "</Item>"
                + "<Revision>" + escapeXml(revision) + "</Revision>"
                + attrXml.toString()
                + "<SpecRefNo>" + escapeXml(specRefNo) + "</SpecRefNo>"
                + "<SpecRevision>" + escapeXml(specRevision) + "</SpecRevision>"
                + "</PLMAttribute>"
                + "</DataArea></InsertDataRequest></plm:InsertData></soapenv:Body>"
                + "</soapenv:Envelope>";
    }

    /**
     * POST to LN API — plain SOAP call, no auth required beyond Content-Type: text/xml.
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void post_ln_attributes(String soapXmlBody) throws Exception
    {
        String lnTargetURL = Properties.ln_url;

        HashMap headers = new HashMap();
        headers.put("Content-Type", "text/xml");
        headers.put("Accept", "text/xml, application/xml, text/plain, */*");

        System.out.println("[EID_service] POST to LN API -> " + lnTargetURL);
        System.out.println("[EID_service] LN SOAP request body: " + soapXmlBody);

        HttpResponse response = load_url(httpClient, "POST", "text/xml", soapXmlBody, lnTargetURL, headers);

        System.out.println("[EID_service] LN API response status: " + response.statusCode());
        System.out.println("[EID_service] LN API response body : " + response.body());
    }

    private String escapeXml(String s)
    {
        if (s == null)
        {
            return "";
        }

        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    // ================================================================
    // GENERIC HTTP UTILITY
    // ================================================================
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static HttpResponse load_url(HttpClient client, String method, String content_type,
                                        String post_data, String sURL, HashMap headers) throws Exception
    {
        HttpRequest.Builder requestbuilder = HttpRequest.newBuilder()
                .uri(URI.create(sURL))
                .method(method, HttpRequest.BodyPublishers.ofString(post_data));

        if (content_type != null && !content_type.isEmpty())
        {
            requestbuilder.setHeader("Content-Type", content_type);
        }

        for (Object entryObj : headers.entrySet())
        {
            Map.Entry entry = (Map.Entry) entryObj;
            if (entry.getValue() != null)
            {
                requestbuilder.setHeader(entry.getKey().toString(), entry.getValue().toString());
            }
        }

        HttpRequest request = requestbuilder.build();
        long start = System.currentTimeMillis();
        HttpResponse response = client.send(request, HttpResponse.BodyHandlers.ofString());
        long duration = System.currentTimeMillis() - start;

        System.out.println("[EID_service] [" + method + "] " + sURL + " -> HTTP " + response.statusCode()
                + " (" + duration + "ms)");
        return response;
    }
}