package exchange;

import java.net.InetAddress;
import java.net.URI;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageListener;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import jakarta.jms.Topic;

import org.apache.activemq.ActiveMQConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import exchange.util.EID_service;
import exchange.properties.Properties;

/**
 * ConsumerMultipleTopicSimple — Consolidated JMS event listener.
 * Single durable subscription. Routes events to:
 * 1) handleDrawingTitleUpdate() -> Drawing statusChanged -> FROZEN
 * 2) handleSpecSheetLnSync() -> Document statusChanged -> RELEASED (Spec-Sheet)
 *
 * DIAGNOSTIC LOGGING:
 * Every stage of startup (DNS lookup, TCP/JMS connect, session, subscribe) is
 * individually timestamped and logged. If startup hangs, the last printed
 * [STAGE] line tells you exactly which step it is stuck on. A background
 * heartbeat also confirms every 60s that the listener thread is alive and
 * genuinely waiting for events (as opposed to silently dead).
 */
public class ConsumerMultipleTopicSimple
{
    private static final String url = Properties.jmsurl;
    private static final String tenantid = Properties.tenantid;
    private static final String agent_id = Properties.agent_id;
    private static final String agent_credentials = Properties.agent_credentials;

    private static final String CLIENT_ID = "EventListenerClient_LOCAL_" + System.getProperty("user.name");
    private static final String SUBSCRIBER_NAME = "EventListener_Durable_Sub";

    // How long we allow the initial JMS connect (DNS + TCP + TLS + handshake) to run
    // before we give up on that attempt and log a clear TIMEOUT message.
    private static final int CONNECT_TIMEOUT_SECONDS = 30;

    // How many times we retry a failed/timed-out connect attempt before giving up entirely.
    private static final int MAX_CONNECT_ATTEMPTS = 3;

    // Delay between retry attempts.
    private static final int RETRY_DELAY_SECONDS = 15;

    // How often the heartbeat prints once the listener is ACTIVE.
    private static final int HEARTBEAT_INTERVAL_SECONDS = 60;

    private static final DateTimeFormatter TS_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private static ActiveMQConnection connection = null;
    private static Session session = null;
    private static MessageConsumer consumer = null;
    private static volatile boolean running = false;
    private static volatile long startedAtMillis = 0L;
    private static volatile long lastEventReceivedAtMillis = 0L;
    private static volatile long eventsReceivedCount = 0L;

    private static ScheduledExecutorService heartbeatExecutor = null;

    public static void main(String[] args)
    {
        startListener();
    }

    // ================================================================
    // LOGGING HELPER — every line is timestamped so a hang is diagnosable
    // ================================================================
    private static void log(String message)
    {
        String ts = LocalDateTime.now().format(TS_FORMAT);
        System.out.println("[" + ts + "] " + message);
    }

    private static void logErr(String message)
    {
        String ts = LocalDateTime.now().format(TS_FORMAT);
        System.err.println("[" + ts + "] " + message);
    }

    public static synchronized void startListener()
    {
        if (running)
        {
            log("[EventListener] Already running. Skipping duplicate start.");
            return;
        }

        log("==============================================================");
        log("[EventListener] STARTING Consolidated Event Listener");
        log("[EventListener] Watching: Drawing->FROZEN | Document->RELEASED(Spec-Sheet)");
        log("[EventListener] Config -> JMS URL: " + url);
        log("[EventListener] Config -> Tenant ID: " + tenantid);
        log("[EventListener] Config -> Agent ID: " + maskAgentId(agent_id));
        log("==============================================================");

        for (int attempt = 1; attempt <= MAX_CONNECT_ATTEMPTS; attempt++)
        {
            log("[EventListener][ATTEMPT " + attempt + "/" + MAX_CONNECT_ATTEMPTS + "] Starting connect sequence...");

            boolean success = attemptConnectAndSubscribe();

            if (success)
            {
                running = true;
                startedAtMillis = System.currentTimeMillis();
                log("[EventListener][JMS] Listener ACTIVE. Waiting for events...");
                startHeartbeat();
                return;
            }

            if (attempt < MAX_CONNECT_ATTEMPTS)
            {
                log("[EventListener] Attempt " + attempt + " failed. Retrying in "
                        + RETRY_DELAY_SECONDS + " seconds...");
                try
                {
                    Thread.sleep(RETRY_DELAY_SECONDS * 1000L);
                }
                catch (InterruptedException ie)
                {
                    Thread.currentThread().interrupt();
                    logErr("[EventListener] Retry wait interrupted. Aborting startup.");
                    return;
                }
            }
        }

        logErr("==============================================================");
        logErr("[EventListener] STARTUP FAILED after " + MAX_CONNECT_ATTEMPTS + " attempts.");
        logErr("[EventListener] The listener is NOT running and will NOT receive events.");
        logErr("[EventListener] Most likely cause: this server cannot reach " + safeHostPort(url)
                + " over the network (firewall / VPN / routing).");
        logErr("[EventListener] Verify with: telnet/curl to that host:port from THIS server.");
        logErr("==============================================================");
        running = false;
    }

    /**
     * Runs one full connect+subscribe sequence with a hard timeout, so a network-level
     * hang cannot block silently forever. Returns true only if the listener reached
     * fully ACTIVE state (subscribed and listening).
     */
    private static boolean attemptConnectAndSubscribe()
    {
        // ---- STAGE 0: DNS pre-check (isolates DNS failure from TCP/handshake hang) ----
        String hostPort = safeHostPort(url);
        String hostOnly = hostPort.contains(":") ? hostPort.substring(0, hostPort.indexOf(':')) : hostPort;
        try
        {
            log("[STAGE 0/4][DNS] Resolving host: " + hostOnly + " ...");
            long dnsStart = System.currentTimeMillis();
            InetAddress addr = InetAddress.getByName(hostOnly);
            long dnsMs = System.currentTimeMillis() - dnsStart;
            log("[STAGE 0/4][DNS] Resolved " + hostOnly + " -> " + addr.getHostAddress()
                    + " (" + dnsMs + "ms)");
        }
        catch (Exception dnsEx)
        {
            logErr("[STAGE 0/4][DNS] FAILED to resolve host: " + hostOnly
                    + " | Error: " + dnsEx.getMessage());
            logErr("[STAGE 0/4][DNS] This means DNS itself is broken for this host from this server.");
            return false;
        }

        // ---- STAGE 1-3: connect + session + subscribe, wrapped in a hard timeout ----
        ExecutorService connectExecutor = Executors.newSingleThreadExecutor(r ->
        {
            Thread t = new Thread(r, "EventListener-Connect-Worker");
            t.setDaemon(true);
            return t;
        });

        try
        {
            Callable<Boolean> connectTask = () ->
            {
                log("[STAGE 1/4][CONNECT] Calling ActiveMQConnection.makeConnection(...) -> "
                        + hostPort + " ...");
                long t1 = System.currentTimeMillis();
                connection = ActiveMQConnection.makeConnection(agent_id, agent_credentials, url);
                log("[STAGE 1/4][CONNECT] makeConnection() returned in "
                        + (System.currentTimeMillis() - t1) + "ms");

                connection.setClientID(CLIENT_ID);
                log("[STAGE 1/4][CONNECT] Client ID set: " + CLIENT_ID);

                log("[STAGE 1/4][CONNECT] Calling connection.start() (this performs the actual"
                        + " network handshake to the broker)...");
                long t2 = System.currentTimeMillis();
                connection.start();
                log("[STAGE 1/4][CONNECT] connection.start() completed in "
                        + (System.currentTimeMillis() - t2) + "ms");
                log("[STAGE 1/4][CONNECT] Connected to Message Bus: " + url);

                log("[STAGE 2/4][SESSION] Creating JMS session...");
                session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                log("[STAGE 2/4][SESSION] Session created.");

                String topicname = "3dsevents." + tenantid + ".3DSpace.user";
                log("[STAGE 3/4][SUBSCRIBE] Subscribing to topic: " + topicname);
                Topic topic = session.createTopic(topicname);
                consumer = session.createDurableSubscriber(topic, SUBSCRIBER_NAME);
                log("[STAGE 3/4][SUBSCRIBE] Durable subscription established: " + SUBSCRIBER_NAME);

                consumer.setMessageListener(new EventMessageListener());
                log("[STAGE 4/4][LISTENER] Message listener attached.");

                return Boolean.TRUE;
            };

            Future<Boolean> future = connectExecutor.submit(connectTask);

            try
            {
                future.get(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                return true;
            }
            catch (TimeoutException te)
            {
                logErr("[EventListener] TIMEOUT: connect sequence did not complete within "
                        + CONNECT_TIMEOUT_SECONDS + " seconds.");
                logErr("[EventListener] The last [STAGE] line printed above tells you exactly"
                        + " where it is stuck.");
                logErr("[EventListener] This almost always means a network/firewall/VPN block"
                        + " between this server and " + hostPort + ", NOT a code bug.");
                future.cancel(true);
                cleanupPartialConnection();
                return false;
            }
            catch (Exception ex)
            {
                Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                logErr("[EventListener] Connect sequence FAILED: " + cause.getMessage());
                cause.printStackTrace();
                cleanupPartialConnection();
                return false;
            }
        }
        finally
        {
            connectExecutor.shutdownNow();
        }
    }

    private static void cleanupPartialConnection()
    {
        try
        {
            if (connection != null)
            {
                connection.close();
            }
        }
        catch (Exception ignore)
        {
            // best effort cleanup only
        }
        finally
        {
            connection = null;
            session = null;
            consumer = null;
        }
    }

    /**
     * Prints a heartbeat every HEARTBEAT_INTERVAL_SECONDS confirming the listener
     * is alive and how many events have been received so far. This is the direct
     * answer to "how do I know if it started or not" during normal running.
     */
    private static void startHeartbeat()
    {
        heartbeatExecutor = Executors.newSingleThreadScheduledExecutor(r ->
        {
            Thread t = new Thread(r, "EventListener-Heartbeat");
            t.setDaemon(true);
            return t;
        });

        heartbeatExecutor.scheduleAtFixedRate(() ->
        {
            long uptimeSec = (System.currentTimeMillis() - startedAtMillis) / 1000;
            String lastEvent = lastEventReceivedAtMillis == 0
                    ? "none yet"
                    : ((System.currentTimeMillis() - lastEventReceivedAtMillis) / 1000) + "s ago";

            log("[EventListener][HEARTBEAT] ALIVE | running=" + running
                    + " | uptime=" + uptimeSec + "s"
                    + " | eventsReceived=" + eventsReceivedCount
                    + " | lastEvent=" + lastEvent);
        }, HEARTBEAT_INTERVAL_SECONDS, HEARTBEAT_INTERVAL_SECONDS, TimeUnit.SECONDS);
    }

    private static String maskAgentId(String id)
    {
        if (id == null || id.length() <= 8)
        {
            return "********";
        }
        return id.substring(0, 4) + "..." + id.substring(id.length() - 4);
    }

    /**
     * Extracts "host:port" out of a JMS URL, tolerating both plain ("ssl://host:port")
     * and failover-wrapped ("failover:(ssl://host:port,...)") forms.
     */
    private static String safeHostPort(String jmsUrl)
    {
        try
        {
            String candidate = jmsUrl;
            int parenIdx = candidate.indexOf('(');
            if (parenIdx >= 0)
            {
                int commaIdx = candidate.indexOf(',', parenIdx);
                int endIdx = commaIdx > 0 ? commaIdx : candidate.indexOf(')', parenIdx);
                candidate = candidate.substring(parenIdx + 1, endIdx > 0 ? endIdx : candidate.length());
            }
            URI parsed = new URI(candidate);
            return parsed.getHost() + ":" + parsed.getPort();
        }
        catch (Exception e)
        {
            return jmsUrl;
        }
    }

    public static synchronized void stopListener()
    {
        log("[EventListener] Stop requested.");

        if (heartbeatExecutor != null)
        {
            heartbeatExecutor.shutdownNow();
            heartbeatExecutor = null;
        }

        try
        {
            if (consumer != null)
            {
                consumer.close();
                consumer = null;
                log("[EventListener] JMS consumer closed cleanly.");
            }

            if (session != null)
            {
                session.close();
                session = null;
                log("[EventListener] JMS session closed cleanly.");
            }

            if (connection != null)
            {
                connection.close();
                connection = null;
                log("[EventListener] JMS connection closed cleanly.");
            }
        }
        catch (Exception e)
        {
            logErr("[EventListener] Error while stopping listener: " + e.getMessage());
            e.printStackTrace();
        }
        finally
        {
            running = false;
        }
    }

    // ================================================================
    // MESSAGE LISTENER — ROUTER
    // ================================================================
    static class EventMessageListener implements MessageListener
    {
        @Override
        public void onMessage(Message message)
        {
            eventsReceivedCount++;
            lastEventReceivedAtMillis = System.currentTimeMillis();

            try
            {
                if (!(message instanceof TextMessage))
                {
                    log("[EventListener] Ignored non-text message.");
                    return;
                }

                String json_stream = ((TextMessage) message).getText();
                log("\n------------------------------------------------------------");
                log("[EventListener] Raw event #" + eventsReceivedCount + " received:\n" + json_stream);

                JSONParser parser = new JSONParser();
                JSONObject rootJson = (JSONObject) parser.parse(json_stream);
                JSONObject dataJson = (JSONObject) new JSONParser().parse(rootJson.get("data").toString());

                String user = safeGet(dataJson, "user");
                String eventType = safeGet(dataJson, "eventType");

                JSONObject subjectJson = (JSONObject) new JSONParser().parse(dataJson.get("subject").toString());
                String type = safeGet(subjectJson, "type");
                String objectId = safeGet(subjectJson, "identifier");

                String newState = "";
                Object objField = dataJson.get("object");
                if (objField != null)
                {
                    JSONObject objectJson = (JSONObject) new JSONParser().parse(objField.toString());
                    newState = safeGet(objectJson, "Value");
                }

                log("[EventListener] user : " + user);
                log("[EventListener] eventType : " + eventType);
                log("[EventListener] type : " + type);
                log("[EventListener] objectId : " + objectId);
                log("[EventListener] newState : " + newState);

                if (type.equalsIgnoreCase("Drawing")
                        && eventType.equalsIgnoreCase("statusChanged")
                        && newState.equalsIgnoreCase("FROZEN"))
                {
                    log("[EventListener] ROUTING -> Drawing Title Update Handler");
                    handleDrawingTitleUpdate(objectId, user);
                }
                else if (type.equalsIgnoreCase("Document")
                        && eventType.equalsIgnoreCase("statusChanged")
                        && newState.equalsIgnoreCase("RELEASED"))
                {
                    log("[EventListener] ROUTING -> Spec-Sheet LN Sync Handler");
                    handleSpecSheetLnSync(objectId, user);
                }
                else if (type.equalsIgnoreCase("Document")
                        && eventType.equalsIgnoreCase("statusChanged")
                        && newState.equalsIgnoreCase("FROZEN"))
                {
                    log("[EventListener] ROUTING -> Form1 LN Sync Handler");
                    form1documentLnSync(objectId, user);
                }
                else
                {
                    log("[EventListener] SKIPPED -> no matching handler for type="
                            + type + ", eventType=" + eventType + ", newState=" + newState);
                }
            }
            catch (ParseException e)
            {
                logErr("[EventListener] JSON parse error: " + e.getMessage());
                e.printStackTrace();
            }
            catch (Exception e)
            {
                logErr("[EventListener] Unexpected error: " + e.getMessage());
                e.printStackTrace();
            }
            finally
            {
                log("------------------------------------------------------------\n");
            }
        }

        private String safeGet(JSONObject obj, String key)
        {
            Object v = obj.get(key);
            return v != null ? v.toString() : "";
        }
    }

    // ══════════════════════════════════════════════════════════════
    // METHOD 1: DRAWING TITLE UPDATE
    // Trigger: Drawing statusChanged -> FROZEN
    // ══════════════════════════════════════════════════════════════
    public static void handleDrawingTitleUpdate(String drawingId, String user)
    {
        final String secContext = Properties.sec_context;

        try
        {
            log("[DrawingTitle] >>> START | Drawing ID: " + drawingId + " | Triggered by: " + user);

            EID_service svc = new EID_service(drawingId);
            svc.prepareAuthorizationHeaderValue();

            String drawingJson = svc.get_drawing_with_parent(drawingId, secContext);
            JSONObject drwJson = (JSONObject) new JSONParser().parse(drawingJson);
            JSONArray drwMembers = (JSONArray) drwJson.get("member");

            if (drwMembers == null || drwMembers.isEmpty())
            {
                logErr("[DrawingTitle] No Drawing data returned. Aborting.");
                return;
            }

            JSONObject drwObj = (JSONObject) drwMembers.get(0);
            String drawingTitle = drwObj.get("title") != null ? drwObj.get("title").toString() : "";
            String drawingCestamp = drwObj.get("cestamp") != null ? drwObj.get("cestamp").toString() : "";

            log("[DrawingTitle] Current Drawing title : " + drawingTitle);
            log("[DrawingTitle] Current Drawing cestamp: " + drawingCestamp);

            String vpmId = null;
            Object parentEngItemsObj = drwObj.get("dsdrw:parentEngItems");
            if (parentEngItemsObj != null)
            {
                JSONObject parentJson = (JSONObject) new JSONParser().parse(parentEngItemsObj.toString());
                JSONArray parentMembers = (JSONArray) parentJson.get("member");
                if (parentMembers != null && !parentMembers.isEmpty())
                {
                    vpmId = ((JSONObject) parentMembers.get(0)).get("id").toString();
                    log("[DrawingTitle] Parent VPMReference ID: " + vpmId);
                }
            }

            if (vpmId == null || vpmId.isEmpty())
            {
                logErr("[DrawingTitle] No parent VPMReference found. Aborting.");
                return;
            }

            String vpmJson = svc.get_vpm_details(vpmId, secContext);
            JSONObject vpmParsed = (JSONObject) new JSONParser().parse(vpmJson);
            JSONArray vpmMembers = (JSONArray) vpmParsed.get("member");

            if (vpmMembers == null || vpmMembers.isEmpty())
            {
                logErr("[DrawingTitle] No VPMReference data returned. Aborting.");
                return;
            }

            JSONObject vpmObj = (JSONObject) vpmMembers.get(0);
            String partNumber = "";
            Object entRefObj = vpmObj.get("dseng:EnterpriseReference");
            if (entRefObj != null)
            {
                JSONObject entRefJson = (JSONObject) new JSONParser().parse(entRefObj.toString());
                if (entRefJson.get("partNumber") != null)
                {
                    partNumber = entRefJson.get("partNumber").toString();
                }
            }

            log("[DrawingTitle] VPMReference partNumber: " + partNumber);

            if (partNumber.trim().isEmpty())
            {
                log("[DrawingTitle] partNumber is blank. No update performed.");
                return;
            }

            if (partNumber.trim().equals(drawingTitle.trim()))
            {
                log("[DrawingTitle] Titles already match. No update needed.");
                return;
            }

            log("[DrawingTitle] Mismatch detected. Updating title: '"
                    + drawingTitle + "' -> '" + partNumber + "'");

            svc.patch_drawing_title(drawingId, drawingCestamp, partNumber, secContext);

            log("[DrawingTitle] <<< SUCCESS | Drawing ID: " + drawingId
                    + " | New Title: " + partNumber);
        }
        catch (Exception e)
        {
            logErr("[DrawingTitle] <<< FAILED | Drawing ID: " + drawingId
                    + " | Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ══════════════════════════════════════════════════════════════
    // METHOD 2: SPEC-SHEET -> LN SYNC
    // Trigger: Document statusChanged -> RELEASED (Document Type = Spec-Sheet)
    // ══════════════════════════════════════════════════════════════
    public static void handleSpecSheetLnSync(String documentId, String user)
    {
        final String secContext = Properties.sec_context_common;

        try
        {
            log("[SpecSheetLN] >>> START | Document ID: " + documentId + " | Triggered by: " + user);

            EID_service svc = new EID_service(documentId);
            svc.prepareAuthorizationHeaderValue();

            String docJson = svc.get_document_details(documentId, secContext);
            JSONObject docRoot = (JSONObject) new JSONParser().parse(docJson);
            JSONArray docData = (JSONArray) docRoot.get("data");

            if (docData == null || docData.isEmpty())
            {
                logErr("[SpecSheetLN] No Document data returned. Aborting.");
                return;
            }

            JSONObject docObj = (JSONObject) docData.get(0);
            JSONObject docElements = (JSONObject) docObj.get("dataelements");

            String docType = docElements.get("ELGI_CA_DocumentType") != null
                    ? docElements.get("ELGI_CA_DocumentType").toString() : "";
            String specRefNo = docElements.get("ELGI_CA_DocumentName") != null
                    ? docElements.get("ELGI_CA_DocumentName").toString() : "";
            String specRevision = docElements.get("revision") != null
                    ? docElements.get("revision").toString() : "";

            log("[SpecSheetLN] Document Type: " + docType);

            if (!docType.equalsIgnoreCase("Spec-Sheet"))
            {
                log("[SpecSheetLN] SKIPPED -> Document type is not Spec-Sheet.");
                return;
            }

            String childJson = svc.get_child_documents(documentId, secContext);
            JSONObject childRoot = (JSONObject) new JSONParser().parse(childJson);
            JSONArray childData = (JSONArray) childRoot.get("data");

            if (childData == null || childData.isEmpty())
            {
                log("[SpecSheetLN] No child documents found. Aborting.");
                return;
            }

            int totalChildDocuments = childData.size();
            int processedSubSheets = 0;
            int successfulLnPosts = 0;

            log("[SpecSheetLN] Total child documents returned: " + totalChildDocuments);

            for (Object childObject : childData)
            {
                JSONObject childObj = (JSONObject) childObject;
                JSONObject childElements = (JSONObject) childObj.get("dataelements");

                if (childElements == null)
                {
                    log("[SpecSheetLN] Skipping child because dataelements is missing.");
                    continue;
                }

                String childDocumentType = childElements.get("ELGI_CA_DocumentType") != null
                        ? childElements.get("ELGI_CA_DocumentType").toString() : "";

                if (!childDocumentType.equalsIgnoreCase("Sub-Sheet"))
                {
                    log("[SpecSheetLN] Skipping child because document type is not Sub-Sheet. Type = "
                            + childDocumentType);
                    continue;
                }

                String subSheetDocId = childObj.get("id") != null
                        ? childObj.get("id").toString() : "";
                String subSheetTitle = childElements.get("title") != null
                        ? childElements.get("title").toString() : "";
                String subSheetRevision = childElements.get("revision") != null
                        ? childElements.get("revision").toString() : "";

                if (subSheetDocId.trim().isEmpty())
                {
                    logErr("[SpecSheetLN] Skipping Sub-Sheet because document ID is blank.");
                    continue;
                }

                processedSubSheets++;

                log("------------------------------------------------------------");
                log("[SpecSheetLN] Processing Sub-Sheet " + processedSubSheets
                        + " of " + totalChildDocuments);
                log("[SpecSheetLN] Sub-Sheet Document ID: " + subSheetDocId);
                log("[SpecSheetLN] Sub-Sheet Title (Item): " + subSheetTitle);
                log("[SpecSheetLN] Sub-Sheet Revision: " + subSheetRevision);

                try
                {
                    String classJson = svc.get_classification_attributes(subSheetDocId, secContext);
                    JSONObject classRoot = (JSONObject) new JSONParser().parse(classJson);
                    JSONArray classMembers = (JSONArray) classRoot.get("member");

                    if (classMembers == null || classMembers.isEmpty())
                    {
                        logErr("[SpecSheetLN] No Classification Attributes found for Sub-Sheet: "
                                + subSheetDocId + ". Skipping this Sub-Sheet.");
                        continue;
                    }

                    JSONObject classMemberObj = (JSONObject) classMembers.get(0);
                    JSONObject classificationAttrs = (JSONObject) classMemberObj.get("ClassificationAttributes");

                    if (classificationAttrs == null)
                    {
                        logErr("[SpecSheetLN] ClassificationAttributes node missing for Sub-Sheet: "
                                + subSheetDocId + ". Skipping this Sub-Sheet.");
                        continue;
                    }

                    JSONArray classAttrMembers = (JSONArray) classificationAttrs.get("member");

                    if (classAttrMembers == null || classAttrMembers.isEmpty())
                    {
                        logErr("[SpecSheetLN] Classification attribute member list is empty for Sub-Sheet: "
                                + subSheetDocId + ". Skipping this Sub-Sheet.");
                        continue;
                    }

                    JSONObject classAttrObj = (JSONObject) classAttrMembers.get(0);
                    JSONArray attributes = (JSONArray) classAttrObj.get("Attributes");

                    if (attributes == null)
                    {
                        logErr("[SpecSheetLN] Attributes list is missing for Sub-Sheet: "
                                + subSheetDocId + ". Skipping this Sub-Sheet.");
                        continue;
                    }

                    log("[SpecSheetLN] Classification Attributes found: " + attributes.size());

                    String soapBody = svc.build_ln_soap_payload(
                            subSheetTitle,
                            subSheetRevision,
                            attributes,
                            specRefNo,
                            specRevision);

                    svc.post_ln_attributes(soapBody);

                    successfulLnPosts++;

                    log("[SpecSheetLN] LN POST SUCCESS for Sub-Sheet: "
                            + subSheetDocId + " | Item: " + subSheetTitle);
                }
                catch (Exception childException)
                {
                    logErr("[SpecSheetLN] LN sync FAILED for Sub-Sheet: "
                            + subSheetDocId + " | Error: " + childException.getMessage());
                    childException.printStackTrace();
                }
            }

            log("============================================================");
            log("[SpecSheetLN] Sync completed for parent Spec-Sheet: " + documentId);
            log("[SpecSheetLN] Total child documents returned: " + totalChildDocuments);
            log("[SpecSheetLN] Valid Sub-Sheets processed: " + processedSubSheets);
            log("[SpecSheetLN] Successful LN POST calls: " + successfulLnPosts);
            log("============================================================");
        }
        catch (Exception e)
        {
            logErr("[SpecSheetLN] <<< FAILED | Document ID: " + documentId
                    + " | Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public static void form1documentLnSync(String documentId, String user)
    {
        final String secContext = Properties.sec_context_common;

        try
        {
            log("[SpecSheetLN] >>> START | Document ID: " + documentId + " | Triggered by: " + user);

            EID_service svc = new EID_service(documentId);
            svc.prepareAuthorizationHeaderValue();

            String docJson = svc.get_document_details(documentId, secContext);
            log("docJson"+docJson);
            JSONObject docRoot = (JSONObject) new JSONParser().parse(docJson);
            JSONArray docData = (JSONArray) docRoot.get("data");

            if (docData == null || docData.isEmpty())
            {
                logErr("[SpecSheetLN] No Document data returned. Aborting.");
                return;
            }

            JSONObject docObj = (JSONObject) docData.get(0);
            JSONObject docElements = (JSONObject) docObj.get("dataelements");

            String docType = docElements.get("ELGI_CA_DocumentType") != null
                    ? docElements.get("ELGI_CA_DocumentType").toString() : "";
            String specRefNo = docElements.get("ELGI_CA_DocumentName") != null
                    ? docElements.get("ELGI_CA_DocumentName").toString() : "";
            String specRevision = docElements.get("revision") != null
                    ? docElements.get("revision").toString() : "";

            log("[SpecSheetLN] Document Type: " + docType);

            if (!docType.equalsIgnoreCase("Form1"))
            {
                log("[SpecSheetLN] SKIPPED -> Document type is not Spec-Sheet.");
                return;
            }

            String childJson = svc.get_child_documents(documentId, secContext);
            JSONObject childRoot = (JSONObject) new JSONParser().parse(childJson);
            JSONArray childData = (JSONArray) childRoot.get("data");

            if (childData == null || childData.isEmpty())
            {
                log("[SpecSheetLN] No child documents found. Aborting.");
                return;
            }

            int totalChildDocuments = childData.size();
            int processedSubSheets = 0;
            int successfulLnPosts = 0;

            log("[SpecSheetLN] Total child documents returned: " + totalChildDocuments);

            for (Object childObject : childData)
            {
                JSONObject childObj = (JSONObject) childObject;
                JSONObject childElements = (JSONObject) childObj.get("dataelements");

                if (childElements == null)
                {
                    log("[SpecSheetLN] Skipping child because dataelements is missing.");
                    continue;
                }

                String childDocumentType = childElements.get("ELGI_CA_DocumentType") != null
                        ? childElements.get("ELGI_CA_DocumentType").toString() : "";

                if (!childDocumentType.equalsIgnoreCase("Sub-Sheet"))
                {
                    log("[SpecSheetLN] Skipping child because document type is not Sub-Sheet. Type = "
                            + childDocumentType);
                    continue;
                }

                String subSheetDocId = childObj.get("id") != null
                        ? childObj.get("id").toString() : "";
                String subSheetTitle = childElements.get("title") != null
                        ? childElements.get("title").toString() : "";
                String subSheetRevision = childElements.get("revision") != null
                        ? childElements.get("revision").toString() : "";

                if (subSheetDocId.trim().isEmpty())
                {
                    logErr("[SpecSheetLN] Skipping Sub-Sheet because document ID is blank.");
                    continue;
                }

                processedSubSheets++;

                log("------------------------------------------------------------");
                log("[SpecSheetLN] Processing Sub-Sheet " + processedSubSheets
                        + " of " + totalChildDocuments);
                log("[SpecSheetLN] Sub-Sheet Document ID: " + subSheetDocId);
                log("[SpecSheetLN] Sub-Sheet Title (Item): " + subSheetTitle);
                log("[SpecSheetLN] Sub-Sheet Revision: " + subSheetRevision);

                try
                {
                    String classJson = svc.get_classification_attributes(subSheetDocId, secContext);
                    JSONObject classRoot = (JSONObject) new JSONParser().parse(classJson);
                    JSONArray classMembers = (JSONArray) classRoot.get("member");

                    if (classMembers == null || classMembers.isEmpty())
                    {
                        logErr("[SpecSheetLN] No Classification Attributes found for Sub-Sheet: "
                                + subSheetDocId + ". Skipping this Sub-Sheet.");
                        continue;
                    }

                    JSONObject classMemberObj = (JSONObject) classMembers.get(0);
                    JSONObject classificationAttrs = (JSONObject) classMemberObj.get("ClassificationAttributes");

                    if (classificationAttrs == null)
                    {
                        logErr("[SpecSheetLN] ClassificationAttributes node missing for Sub-Sheet: "
                                + subSheetDocId + ". Skipping this Sub-Sheet.");
                        continue;
                    }

                    JSONArray classAttrMembers = (JSONArray) classificationAttrs.get("member");

                    if (classAttrMembers == null || classAttrMembers.isEmpty())
                    {
                        logErr("[SpecSheetLN] Classification attribute member list is empty for Sub-Sheet: "
                                + subSheetDocId + ". Skipping this Sub-Sheet.");
                        continue;
                    }

                    JSONObject classAttrObj = (JSONObject) classAttrMembers.get(0);
                    JSONArray attributes = (JSONArray) classAttrObj.get("Attributes");

                    if (attributes == null)
                    {
                        logErr("[SpecSheetLN] Attributes list is missing for Sub-Sheet: "
                                + subSheetDocId + ". Skipping this Sub-Sheet.");
                        continue;
                    }

                    log("[SpecSheetLN] Classification Attributes found: " + attributes.size());

                    String soapBody = svc.build_ln_soap_payload(
                            subSheetTitle,
                            subSheetRevision,
                            attributes,
                            specRefNo,
                            specRevision);

                    svc.post_ln_attributes(soapBody);

                    successfulLnPosts++;

                    log("[SpecSheetLN] LN POST SUCCESS for Sub-Sheet: "
                            + subSheetDocId + " | Item: " + subSheetTitle);
                }
                catch (Exception childException)
                {
                    logErr("[SpecSheetLN] LN sync FAILED for Sub-Sheet: "
                            + subSheetDocId + " | Error: " + childException.getMessage());
                    childException.printStackTrace();
                }
            }

            log("============================================================");
            log("[SpecSheetLN] Sync completed for parent Spec-Sheet: " + documentId);
            log("[SpecSheetLN] Total child documents returned: " + totalChildDocuments);
            log("[SpecSheetLN] Valid Sub-Sheets processed: " + processedSubSheets);
            log("[SpecSheetLN] Successful LN POST calls: " + successfulLnPosts);
            log("============================================================");
        }
        catch (Exception e)
        {
            logErr("[SpecSheetLN] <<< FAILED | Document ID: " + documentId
                    + " | Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}