package exchange;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class ListenerStartup implements ServletContextListener
{
    private Thread listenerThread;

    @Override
    public void contextInitialized(ServletContextEvent sce)
    {
        System.out.println("[ListenerStartup] Application context initialized. Starting event listener thread...");

        listenerThread = new Thread(() ->
        {
            try
            {
                Thread.sleep(5000);
                ConsumerMultipleTopicSimple.startListener();
            }
            catch (InterruptedException e)
            {
                System.out.println("[ListenerStartup] Startup thread interrupted.");
                Thread.currentThread().interrupt();
            }
            catch (Exception e)
            {
                System.err.println("[ListenerStartup] Failed to start listener: " + e.getMessage());
                e.printStackTrace();
            }
        });

        listenerThread.setName("EventListener-Startup-Thread");
        listenerThread.setDaemon(true);
        listenerThread.start();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce)
    {
        System.out.println("[ListenerStartup] Application context destroyed. Stopping event listener...");

        if (listenerThread != null && listenerThread.isAlive())
        {
            listenerThread.interrupt();
        }

        ConsumerMultipleTopicSimple.stopListener();
    }
}